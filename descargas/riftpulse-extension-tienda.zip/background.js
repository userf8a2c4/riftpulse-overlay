// RiftPulse — proceso de fondo (versión de la Chrome Web Store: el overlay viene dentro del paquete).
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
const marcar = () => chrome.storage.local.set({rp_origen: {origen: 'tienda', detalle: '', at: Date.now()}});
chrome.runtime.onInstalled.addListener(marcar);
chrome.runtime.onStartup.addListener(marcar);
// mensajes del overlay: órdenes de Mando y lo que se ve en el video
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg) return;
  if (msg.type === 'rp-cmd-get') { chrome.storage.local.get(['rp_cmd'], o => send(o || {})); return true; }
  if (msg.type === 'rp-pantalla') { chrome.storage.local.set({rp_pantalla: msg.data || null}).then(() => send({ok: true})); return true; }
  if (msg.type === 'rp-reinstalar') { marcar().then(() => send({ok: true})); return true; }
});
